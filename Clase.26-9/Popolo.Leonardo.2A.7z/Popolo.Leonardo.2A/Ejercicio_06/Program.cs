﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_06
{
    class Program
    {
        static void Main(string[] args)
        {
            int anio;

            Console.WriteLine("Ingrese un año: ");
            anio = Convert.ToInt32(Console.ReadLine());
            if (anio % 4 == 0 && !(anio % 100 == 0))
            {
                Console.WriteLine("el año {0} es bisiesto.\n", anio);
            }
            else if (anio % 400 == 0)
            {
                Console.WriteLine("el año {0} es bisiesto.\n", anio);
            }
            else
            {
                Console.WriteLine("el año {0} no es bisiesto.\n", anio);
            }

            Console.ReadKey();
        }
    }
}
