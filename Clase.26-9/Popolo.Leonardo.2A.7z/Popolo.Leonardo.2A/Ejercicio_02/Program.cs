﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_02
{
    class Program
    {
        static void Main(string[] args)
        {
            double num;            

            Console.Write("ingrese un numero: ");
            num = Convert.ToDouble(Console.ReadLine());

            while(num < 0)
            {
                Console.Write("ERROR. Reingrese numero: ");
                num = Convert.ToDouble(Console.ReadLine());
            }

            Console.WriteLine("el cuadrado del numero es: {0} y el cubo es: {1}",Math.Pow(num, 2), Math.Pow(num, 3) );
            Console.ReadKey();
        }
    }
}
