﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_16
{
    class Alumno
    {
        byte nota1;
        byte nota2;
        float notaFinal;
        public string nombre;
        public string apellido;
        int legajo;

        public Alumno(string nombre, string apellido, int legajo)
        {
            this.apellido = apellido;
            this.nombre = nombre;
            this.legajo = legajo;
        }

        public void CalcularFinal()
        {
            Random nota = new Random();

            if (this.nota1 >= 4 && this.nota2 >= 4)
            {
                this.notaFinal = nota.Next(4, 10);
            }
            else
            {
                this.notaFinal = -1;
            }
        }

        public void Estudiar(byte notaUno, byte notaDos)
        {
            this.nota1 = notaUno;
            this.nota2 = notaDos;
        }

        public void Mostrar()
        {
            Console.Write("Nombre y Apellido del alumno: {0} {1}\nLegajo nº{2}", this.nombre, this.apellido, this.legajo);
            if (this.notaFinal >= 4)
            {
                Console.WriteLine("\nNota final del alumno: {0}\n", this.notaFinal);
            }
            else
            {
                Console.WriteLine("\nAlumno Desaprobado.\n");
            }
        }
    }
}
