using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.Clase07
{
    public class PaletaColeccion
    {
        private List<Tempera> _colores;
        private int _cantMaximaElementos;

        private PaletaColeccion() : this(5)
        {

        }

        public PaletaColeccion(int cant)
        {
            this._cantMaximaElementos = cant;
            this._colores = new List<Tempera>();
        }

        private string Mostrar()
        {
            string retorno = "";

            foreach (Tempera temp in this._colores)
            {
                retorno += temp;
            }

            return retorno;
        }

        public static explicit operator string(PaletaColeccion pal)
        {
            string var = "";

            if(pal != null)
                var = pal.Mostrar();
            return var;
        }

        public static implicit operator PaletaColeccion(int num)
        {
            return new PaletaColeccion(num);
        }

        public static bool operator ==(PaletaColeccion pal, Tempera tem)
        {
            bool retorno = false;
            int index = pal._colores.Count;
  
            for (int i = 0; i < index; i++)
            {
                
                    if (pal._colores[i].Equals(tem))
                    {
                        retorno = true;
                        break;
                    }
                
            }           

            return retorno;
        }

        public static bool operator !=(PaletaColeccion pal, Tempera tem)
        {
            return !(pal == tem);
        }

        public static PaletaColeccion operator +(PaletaColeccion pal, Tempera tem)
        {
            int index = 0;
            int index2 = 0;     

            if (pal == tem)
            {
                if ( index2 >= 0)
                pal._colores[index2] += tem;
            }
            else
            {
                if(index > -1)
                pal._colores[index] = tem;
            }

            return pal;
        }

        public static PaletaColeccion operator -(PaletaColeccion pal, Tempera tem)
        {
            int index = 0;
            sbyte a;
            sbyte b;

           /// index = pal.ObtenerIndice(tem);

            a = (sbyte)pal._colores[index];
            b = (sbyte)tem;

            if (pal == tem)
            {
                if (index >= 0)
                {
                    if (a - b <= 0)
                        pal._colores[index] = null;
                    else
                        pal._colores[index] += (sbyte)(b * (-1)); 
                }                  
            }

            return pal;
        }

        //public Tempera this[int indice]
        //{
        //    get
        //    {
        //        if (indice >= this._colores.GetLength(0) || indice < 0)
        //            return null;
        //        else
        //            return this._colores[indice]; //programacion 2/10 parrcial!!!!!!!!!!!!"!·!"·!"·!"
        //    }
        //    set
        //    {
        //        if (indice >= 0 && indice < this._colores.GetLength(0))
        //            this._colores[indice] = value;

        //        else if (indice == this._colores.GetLength(0))
        //        {
        //            Console.WriteLine("No se puede asignar este elemento");
        //            Console.ReadKey();
        //        }
        //    }

        //}









    }
}
