﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_12
{
    class ValidarRespuesta
    {
        static bool val;

        public static bool ValidarS_N(char c)
        {
            if(c == 's')
            {
                val = true;
            }
            else
            {
                val = false;
            }

            return val;
        }
    }
}
