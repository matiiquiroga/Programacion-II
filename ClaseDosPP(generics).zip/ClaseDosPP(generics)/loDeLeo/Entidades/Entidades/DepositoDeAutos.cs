﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public class DepositoDeAutos
    {
        private int _capacidadMaxima;
        private List<Auto> _lista;

        public DepositoDeAutos(int capacidad)
        {
            this._capacidadMaxima = capacidad;
            this._lista = new List<Auto>(this._capacidadMaxima);
        }

        public bool Agregar(Auto a)
        {
            if (this._capacidadMaxima > this._lista.Count)
            {
                this._lista.Add(a);
                return true;
            }

            return false;
        }

        public bool Remover(Auto a)
        {
            if(this.GetIndice(a) != -1)
            {
                this._lista.Remove(a);
                return true;
            }

            return false;
        }

        private int GetIndice(Auto a)
        {
            foreach(Auto c in this._lista)
            {
                if(c == a)
                {
                    return this._lista.IndexOf(c);
                }
            }

            return -1;
        }

        public static bool operator +(DepositoDeAutos d, Auto a)
        {
            if(d.Agregar(a))
            {
                return true;
            }

            return false;
        }

        public static bool operator -(DepositoDeAutos d, Auto a)
        {
            if (d.Remover(a))
            {
                return true;
            }

            return false;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("Capacidad maxima: " + this._capacidadMaxima.ToString());
            sb.AppendLine("\nListado de Autos: ");

            foreach(Auto a in this._lista)
            {
                sb.AppendLine(a.ToString());
            }

            return sb.ToString();
        }
    }
}
