﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades_2
{
    public class Deposito<T>
    {
        private int _capacidadMaxima;
        private List<T> _lista;

        public Deposito(int capacidad)
        {
            this._capacidadMaxima = capacidad;
            this._lista = new List<T>(this._capacidadMaxima);
        }

        public bool Agregar(T a)
        {
            if (this._capacidadMaxima > this._lista.Count)
            {
                this._lista.Add(a);
                return true;
            }

            return false;
        }

        public bool Remover(T a)
        {
            if (this.GetIndice(a) != -1)
            {
                this._lista.Remove(a);
                return true;
            }

            return false;
        }

        private int GetIndice(T a)
        {
            foreach (T c in this._lista)
            {
                if (object.Equals(c, a))
                {
                    return this._lista.IndexOf(c);
                }
            }
            return -1;
        }

        public static bool operator +(Deposito<T> d, T a)
        {
            if (d.Agregar(a))
            {
                return true;
            }

            return false;
        }

        public static bool operator -(Deposito<T> d, T a)
        {
            if (d.Remover(a))
            {
                return true;
            }

            return false;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("Capacidad maxima: " + this._capacidadMaxima.ToString());
            sb.AppendLine("\nListado de Objetos: ");

            foreach (T a in this._lista)
            {
                sb.AppendLine(a.ToString());
            }

            return sb.ToString();
        }
    }
}
