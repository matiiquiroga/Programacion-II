﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Entidades_2
{
    public class DepositoDeCocinas
    {
        private int _capacidadMaxima;
        private List<Cocina> _lista;

        public DepositoDeCocinas(int capacidad)
        {
            this._capacidadMaxima = capacidad;
            this._lista = new List<Cocina>(this._capacidadMaxima);
        }

        public bool Agregar(Cocina a)
        {
            if (this._capacidadMaxima > this._lista.Count)
            {
                this._lista.Add(a);
                return true;
            }

            return false;
        }

        public bool Recuperar(string cadena)
        {
            try
            {
                using (StreamReader archivo = new StreamReader(cadena))
                {
                    Console.WriteLine(archivo.ReadToEnd());
                    return true;
                }
            
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }

        public bool Guardar(string cadena)
        {
            try
            {
                using (StreamWriter archivo = new StreamWriter(cadena, false))
                {
                    archivo.WriteLine(this.ToString());
                }

                return true;
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);

                return false;
            }
            
        }

        public bool Remover(Cocina a)
        {
            if (this.GetIndice(a) != -1)
            {
                this._lista.Remove(a);
                return true;
            }

            return false;
        }

        private int GetIndice(Cocina a)
        {
            foreach (Cocina c in this._lista)
            {
                if (c == a)
                {
                    return this._lista.IndexOf(c);
                }
            }

            return -1;
        }

        public static bool operator +(DepositoDeCocinas d, Cocina a)
        {
            if (d.Agregar(a))
            {
                return true;
            }

            return false;
        }

        public static bool operator -(DepositoDeCocinas d, Cocina a)
        {
            if (d.Remover(a))
            {
                return true;
            }

            return false;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("Capacidad maxima: " + this._capacidadMaxima.ToString());
            sb.AppendLine("\nListado de Cocinas: ");

            foreach (Cocina a in this._lista)
            {
                sb.AppendLine(a.ToString());
            }

            return sb.ToString();
        }
    }
}
