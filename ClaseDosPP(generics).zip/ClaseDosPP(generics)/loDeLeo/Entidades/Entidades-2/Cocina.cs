﻿using System;

namespace Entidades_2
{
    public class Cocina
    {
        private int _codigo;
        private bool _esIndustrial;
        private double _precio;

        public int Codigo {

            get
            {
                return this._codigo;
            }

        }

        public bool EsIndustrial
        {

            get
            {
                return this._esIndustrial;
            }

        }

        public double Precio
        {

            get
            {
                return this._precio;
            }

        }

        public Cocina(int codigo, double precio, bool esIndustrial)
        {
            this._precio = precio;
            this._esIndustrial = esIndustrial;
            this._codigo = codigo;
        }

        public static bool operator ==(Cocina a, Cocina b)
        {
            if(a._codigo == b._codigo)
            {
                return true;
            }

            return false;
        }

        public static bool operator !=(Cocina a, Cocina b)
        {
            return !(a == b);
        }

        public override bool Equals(object obj)
        {
            if(obj is Cocina)
            {
                if((Cocina)obj == this)
                {
                    return true;
                }
            }

            return false;
        }

        public override string ToString()
        {
            return string.Format("Codigo " + this._codigo + " Precio: " + this._precio + " Industrial: " + this._esIndustrial);
        }
    }
}
