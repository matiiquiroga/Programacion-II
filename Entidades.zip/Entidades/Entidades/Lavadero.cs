﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Lavadero
    {
        List<Vehiculo> _vehiculos;
        static float _precioAuto;
        static float _precioCamion;
        static float _precioMoto;
        string _razonSocial;

        private Lavadero()
        {
            this._vehiculos = new List<Vehiculo>();
        }

        public Lavadero(string razonSocial) : this()
        {
            this._razonSocial = razonSocial;
        }

        static Lavadero()
        {
            Random generadorPrecio= new Random();

            _precioAuto = generadorPrecio.Next(150, 565);
            _precioCamion = generadorPrecio.Next(150, 565);
            _precioMoto = generadorPrecio.Next(150, 565);
        }

        public string LavaderoToString
        {
            get
            {
                StringBuilder sb = new StringBuilder();

                sb.AppendFormat("Razon social: {0}\n", this._razonSocial );
                sb.AppendFormat("Total por manuales: {0:N}\n", PrecioDeManuales);
                sb.AppendFormat("Total por novelas: {0:N}\n", e.PrecioDeNovelas);
                sb.AppendFormat("Total: {0:N}\n", e.PrecioTotal);

                sb.AppendLine("****************************\n" +
                              "Listado de libros\n" +
                              "****************************");
            }
        }

        public double MostrarTotalFacturado()
        {
            double retorno;
            float totalFacturado=0;

            foreach( Vehiculo item in this._vehiculos)
            {
                if (item is Auto)
                {
                    totalFacturado +=  _precioAuto;
                }
                else if (item is Camion)
                {
                    totalFacturado += _precioCamion;
                }
                else if (item is Moto)
                {
                    totalFacturado += _precioMoto;
                }
            }

            retorno = totalFacturado;
            return retorno;
        }

        public double MostrarTotalFacturado(EVehiculo vehiculos)
        {
            double retorno=0;

            foreach (Vehiculo item in this._vehiculos)
            {
                switch (vehiculos)
                {
                    case EVehiculo.Auto:
                        if (item is Auto)
                            retorno += _precioAuto;
                        break;
                    case EVehiculo.Moto:
                        if (item is Moto)
                            retorno += _precioMoto;
                        break;
                    case EVehiculo.Camion:
                        if (item is Camion)
                            retorno += _precioMoto;
                        break;
                    default:
                        break;
                }               
            }

            return retorno;
        }

        











    }
}
