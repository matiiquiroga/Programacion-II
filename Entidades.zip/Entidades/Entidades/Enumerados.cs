﻿public enum EMarcas
{
    Honda,
    Ford,
    Zanella,
    Scania,
    Iveco,
    Fiat
}

public enum EVehiculo
{
    Auto,
    Moto,
    Camion
}