﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Moto : Vehiculo
    {
        float _Cilindrada;

        public Moto(string patente, byte ruedas, EMarcas marca, float cilindrada) : base (patente, ruedas, marca)
        {
            this._Cilindrada = cilindrada;
        }

        public Moto(EMarcas marca, float cilindrada, string patente, int ruedas) : this (patente, 2, marca, cilindrada)
        {

        }
    }
}
