﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Vehiculo
    {
        protected string _patente;
        protected byte _cantRuedas;
        protected EMarcas _marca;


        public string patente
        {
            get
            {
                return this._patente;
            }
        }

        public EMarcas Marca
        {
            get
            {
                return this._marca;
            }
                
        }

        public byte cantRuedas
        {
            get
            {
                return this._cantRuedas;

            }
            set
            {
                this._cantRuedas = value;
            }
        }

        protected virtual string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("Patente: {0}\r\n", this.patente);
            sb.AppendFormat("Cantidad de rueda: {0}\r\n", this.cantRuedas);
            sb.AppendFormat("COLOR EMPAQUE  : {0}\r\n", this._marca);
            sb.AppendLine("---------------------");

            return sb.ToString();
        }

        public Vehiculo(string patente, byte ruedas, EMarcas marca)
        {
            this._patente = patente;
            this._cantRuedas = ruedas;
            this._marca = marca;
        }

        public override string ToString()
        {
            return this.Mostrar();
        }

        public static bool operator ==(Vehiculo v1, Vehiculo v2)
        {
            bool retorno = false;

            if ((v1._marca == v2._marca) && (v1.patente == v2.patente))
                retorno = true;

            return retorno;
        }

        public static bool operator !=(Vehiculo v1, Vehiculo v2)
        {
            return !(v1 == v2);
        }


    }
}
