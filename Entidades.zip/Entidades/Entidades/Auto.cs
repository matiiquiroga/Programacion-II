﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Auto : Vehiculo
    {
        protected int _cantidadAsientos;

        public Auto(string patente, byte ruedas, EMarcas marca, int asientos) : base (patente, ruedas, marca)
        {
            this._cantidadAsientos = asientos;
        }

        public Auto(string patente, EMarcas marca, int asientos) : base(patente, 4, marca)
        {

        }

        protected override string Mostrar()
        {
           return  base.ToString() + "Asientos: \r\n" + this._cantidadAsientos;
        }

        public override string ToString()
        {
            return this.Mostrar();
        }


    }
}
