﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Camion : Vehiculo
    {
        protected float _tara;

        public Camion(string patente, byte ruedas, EMarcas marca, float tara) : base(patente, ruedas, marca)
        {
            this._tara = tara;
        }

        public Camion(Vehiculo v, float tara) : this (v.patente, 8 ,v.Marca, tara )
        {
            
        }

        protected override string Mostrar()
        {
            return base.ToString() + "Tara: \r\n" + this._tara;
        }

        public override string ToString()
        {
            return this.Mostrar();
        }




    }
}
