﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    class Tempera
    {
        sbyte _cantidad;
        ConsoleColor _color;
        string _marca;

        public Tempera(sbyte cantidad, ConsoleColor color, string marca)
        {
            this._cantidad = cantidad;
            this._color = color;
            this._marca = marca;
        }

        private string mostrar()
        {
            return "Cantidad" + this._cantidad + " color" + this._color + "marca" + this._marca;
        }

        public static implicit operator string( Tempera tempera)
        {
            return tempera.mostrar();
        }

        public static explicit operator sbyte(Tempera tempera)
        {
            return tempera._cantidad;
        }

        public static bool operator ==(Tempera t1, Tempera t2)
        {
            bool respuesta = false;
            if (t1._color == t2._color && t1._marca == t2._marca)
                respuesta = true;
            return respuesta;
        }

        public static bool operator !=(Tempera t1, Tempera t2)
        {
            return !(t1 == t2);
        }

        public static Tempera operator +(Tempera tempera1, sbyte cant)
        {
            Tempera aux = new Tempera((sbyte)(tempera1._cantidad + cant), tempera1._color, tempera1._marca);
            return aux;
        }

        public static Tempera operator -(Tempera tempera1, Tempera tempera2)
        {
            Tempera tempera3 = new Tempera(tempera1._cantidad,tempera1._color,tempera1._marca);

            if(tempera1 == tempera2)
            {
                tempera3 += tempera2._cantidad;
            }
            return tempera3;

        }

    }
}
