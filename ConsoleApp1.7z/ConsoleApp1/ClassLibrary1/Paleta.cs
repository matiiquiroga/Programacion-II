﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    class Paleta
    {
        Tempera[] _Colores;
        int _cantMaximaElementos = 5;

        private Paleta() : this(5)
        {

        }

        private Paleta(int cant)
        {
            this._cantMaximaElementos = cant;
            this._Colores = new Tempera[this._cantMaximaElementos];
        }

        private string mostrar()
        {
            string retorno = "";

            retorno += this._cantMaximaElementos;

            foreach (Tempera item in this._Colores)
            {
                retorno += item;
            }

            return retorno;
        }

        public static explicit operator string(Paleta n)
        {
            return n.mostrar();
        }

        public static implicit operator Paleta(int n)
        {
            Paleta nuevaPaleta = new Paleta(n);
            return nuevaPaleta;
        }

        public static bool operator ==(Paleta paleta, Tempera Tempera)
        {
            bool retorno = false;
            int contador = 0;
            foreach (Tempera item in paleta._Colores)
            {
                if (paleta._Colores.GetValue(contador) != null)
                {
                    if (Tempera == item)
                    {
                        retorno = true;
                    }
                }

                contador++;
            }
            return retorno;
        }

        public static bool operator !=(Paleta paleta, Tempera Tempera)
        {
            return !(paleta == Tempera);
        }

        public static Paleta operator +(Paleta paleta, Tempera tempera)
        {
          
                if(paleta==tempera)
                {
                    paleta._Colores[]
                }
            

        }
        

        private int ObtenerIndice() ////// falta el obtener indice que devuelve un entero y recibe una tempera
        {
            int retorno= -1;
            int indice = 0;

            foreach(Tempera item in this._Colores)
            {
                if (this._Colores.GetValue(indice) == null)
                {
                    retorno = indice;
                    break;
                }
                indice++;
            }
      
            return retorno;
        }

        private int ObtenerIndice(Tempera tempera) ////aca esta 
        {


        }

    }
}
