using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using System.Xml.Serialization;

namespace Prueba_base_de_datos
{
  public delegate void MiDelegado();

  public class Televisor
  {

    public int id;
    public double precio;
    public string marca;
    public int pulgadas;
    public string pais;
    public event MiDelegado evento;

    public Televisor(int id, double precio, string marca, int pulgadas, string pais)
    {
      this.id = id;
      this.precio = precio;
      this.pulgadas = pulgadas;
      this.pais = pais;
      this.marca = marca;
    }

    public Televisor()
    {

    }

    public bool Insertar()
    {
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);

      SqlCommand comando = new SqlCommand();

      comando.CommandText = "insert into Televisores values (" + this.id + ", '" + this.marca + "' ," + this.precio + ", " + this.pulgadas + ", '" + this.pais + "')";
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;

      try
      {
        conexion.Open();
        comando.ExecuteNonQuery();
        conexion.Close();
        this.evento();

        return true;
      }
      catch (Exception ex)
      {
        Console.WriteLine(ex.Message);
        return false;
      }

    }

    public static bool Modificar(Televisor t)
    {
      bool retorno = false;
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
      SqlCommand comando = new SqlCommand();

      comando.CommandText = "UPDATE Televisores SET [codigo] = " + t.id +", [Marca] = '" + t.marca + "', [precio] =" + t.precio + "', [pulgadas] ="+ t.pulgadas + ", [pais] = '" + t.pais;
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;

      try
      {
        conexion.Open();
        comando.ExecuteNonQuery();
        conexion.Close();
        retorno = true;
      }
      catch (Exception ex)
      {
        Console.WriteLine(ex.Message);
      }

      return retorno;
    }

    public static bool Borrar(Televisor t)
    {
      bool retorno = false;
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
      SqlCommand comando = new SqlCommand();

      comando.CommandText = "DELETE Televisores WHERE [codigo] = " + t.id;
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;

      try
      {
        conexion.Open();
        comando.ExecuteNonQuery();
        conexion.Close();
        retorno = true;
      }
      catch (Exception ex)
      {
        Console.WriteLine(ex.Message);
      }

      return retorno;
    }

    public static List<Televisor> TraerTodos()
    {
      List<Televisor> lista = new List<Televisor>();
      SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);

      SqlCommand comando = new SqlCommand();

      comando.CommandText = "select * from Televisores";
      comando.CommandType = System.Data.CommandType.Text;
      comando.Connection = conexion;

      conexion.Open();
      SqlDataReader lector = comando.ExecuteReader();

      while(lector.Read())
      {
        Console.WriteLine(lector[0] + "-" + lector[1] + "-" + lector[2] + "-" + lector[3] + "-" + lector[4]);
        lista.Add(new Televisor(lector.GetInt32(0), lector.GetDouble(2), lector.GetString(1), lector.GetInt32(3), lector.GetString(4)));
      }
      conexion.Close();

      conexion.Open();

      lector = comando.ExecuteReader();

      DataTable televisores = new DataTable("televisores");
      televisores.Load(lector);
      televisores.WriteXmlSchema("Televisores_esquema.xml");
      televisores.WriteXml("Televisores_dt.xml");

      conexion.Close();

      DataTable nuevoDT = new DataTable();
      nuevoDT.WriteXmlSchema("Televisores_esquema.xml");
      nuevoDT.WriteXml("Televisores_dt.xml");

      return lista;

    }


    //public static Televisor TraerUno(int pk)
    //{

    //}


    

    public override string ToString()
    {
      return this.id.ToString() + " " + this.marca + " " + this.precio.ToString() + " " + this.pulgadas.ToString() + " " + this.pais;
    }




  }
}
