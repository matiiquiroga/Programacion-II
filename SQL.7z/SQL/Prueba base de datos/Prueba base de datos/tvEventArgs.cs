using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prueba_base_de_datos
{
  public class tvEventArgs : EventArgs
  {
    public DateTime Hora { get; set; }
  }
}
