using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prueba_base_de_datos;

namespace EventosConsolaTest
{
  class Program
  {
    static void Main(string[] args)
    {
      

    }

  }
}
