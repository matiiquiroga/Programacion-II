﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace TestEntidades
{
    class Program
    {
        static void Main(string[] args)
        {
            string laSalida;

            string pathEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);///pathEscritorio = @"C:\Users\alumno\Desktop\testEscritorio.txt";
            //string pathMisDocus = @"C:\Users\alumno\Documents\testMisDocus.txt";
            //string pathImagenes = @"C:\Users\alumno\Pictures\testImagenes.txt";

            bool todoOk= AdministradoArchivos.Escribir(pathEscritorio + "testEscritorio.txt", "esto es una prueba de archivo de escritorio");
            if (todoOk)
                Console.WriteLine("todook");
            else
                Console.WriteLine("todoMal");

            // todoOk = AdministradoArchivos.Escribir(pathMisDocus, "esto es una prueba de archivo de docu");
            //if (todoOk)
            //    Console.WriteLine("todook");
            //else
            //    Console.WriteLine("todoMal");

            // todoOk = AdministradoArchivos.Escribir(pathImagenes, "esto es una prueba de archivo de imagen");
            //if (todoOk)
            //    Console.WriteLine("todook");
            //else
            //    Console.WriteLine("todoMal");

            todoOk = AdministradoArchivos.Leer(pathEscritorio + "testEscritorio.txt", out laSalida);
            Console.WriteLine(laSalida);
            Console.ReadKey();

            
            

        }
    }
}
