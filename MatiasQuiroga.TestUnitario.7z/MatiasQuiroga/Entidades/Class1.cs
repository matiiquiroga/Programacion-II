﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Entidades
{
    public static class AdministradoArchivos
    {
        public static bool Escribir(string path, string cadena)
        {
            bool retorno = false;

            try
            {
                using (StreamWriter archivo = new StreamWriter(path, false))
                {
                    archivo.WriteLine(cadena);
                    retorno = true;
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);

                retorno= false;
            }

            return retorno;
        }

        public static bool Leer(string path, out string salida)
        {
            bool retorno = false;

            try
            {
                using (StreamReader archivo = new StreamReader(path, false))
                {
                    salida = archivo.ReadToEnd();
                    retorno = true;
                }
            }
            catch (Exception e)
            {
                salida = "no se pudo leer archivo";
                Console.WriteLine(e.Message);
                retorno = false;
            }

            return retorno;
        }

    }
}
