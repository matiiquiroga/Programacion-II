﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Cosa
    {
        public string cadena;
        public double numero;
        public DateTime fecha;

        public static string Mostrar(Cosa cosita)
        {
            return cosita.Mostrar();
        }
        private string Mostrar()
        {
            string retorno = "";

            retorno = this.cadena + " " + this.numero.ToString() + " " + this.fecha.ToLongDateString();

            return retorno;
        }
        public void EstablecerValor(string cadena)
        {
            this.cadena = cadena;
        }
        public void EstablecerValor(double numerito)
        {
            this.numero = numerito;
        }
        public void EstablecerValor(DateTime fechita)
        {
            this.fecha = fechita;
        }
        public Cosa()
        {
            this.cadena = "sin valor";
            this.fecha = DateTime.Now;
            this.numero = 1.9;
        }
        public Cosa(string c)
        {
            this.cadena = c;
            this.fecha = DateTime.Now;
            this.numero = 1.9;
        }
    }
}
