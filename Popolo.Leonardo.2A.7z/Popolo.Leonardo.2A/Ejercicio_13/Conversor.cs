﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_13
{
    class Conversor
    {
        public static string DecimalABinario(int num)
        {
            string binario = "";
            if (num > 0)
            {
                while (num > 0)
                {
                    if (num % 2 == 0)
                    {
                        binario = "0" + binario;
                    }
                    else
                    {
                        binario = "1" + binario;
                    }
                    num = (int)num / 2;
                }
            }
            else if (num == 0)
            {
                binario = "0";
            }
            else
            {
                binario = "No se puede convertir el numero. Ingrese solamente numeros positivos";
            }

            return binario;
        }

        public static int BinarioADecimal(string binario)
        {
            int resp = Convert.ToInt32(binario, 2);
            return resp;
        }
    }
}
