﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_12
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            bool val;
            char resp;

            do
            {
                Console.Write("Ingrese un numero: ");
                num = int.Parse(Console.ReadLine());
                Console.Write("Desea seguir ingresando? (s/n): ");
                resp = Convert.ToChar(Console.ReadLine());
                val = ValidarRespuesta.ValidarS_N(resp);

            }while(val);
            
        }
    }
}
