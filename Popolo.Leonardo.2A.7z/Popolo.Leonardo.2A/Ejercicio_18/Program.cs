﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Geometria;

namespace Ejercicio_18
{
    class PruebaGeometria
    {
        static void Main(string[] args)
        {
            Rectangulo r = new Rectangulo(new Punto(-12, -5), new Punto(-6, -1));

            MostrarRectangulo(r);

            Console.ReadKey();
        }

        /// <summary>
        /// Muestra los atributos del rectangulo pasado como argumento.
        /// </summary>
        /// <param name="rectangulo">
        /// Rectangulo a mostrar.
        /// </param>
        public static void MostrarRectangulo(Rectangulo rectangulo)
        {
            Console.WriteLine(". Lado: {0}", rectangulo.Lado());
            Console.WriteLine(". Base: {0}", rectangulo.B());
            Console.WriteLine(". Area: {0,0:#,###.00}", rectangulo.Area());
            Console.WriteLine(". Perimetro: {0,0:#,###.00}", rectangulo.Perimetro());
        }
    }
}
