﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_17
{
    class Program
    {
        static void Main(string[] args)
        {
            Boligrafo boligrafoAzul = new Boligrafo(ConsoleColor.Blue, 100);
            Boligrafo boligrafoRojo = new Boligrafo(ConsoleColor.Red, 50);
            string dibujo;
            byte tintaAGastar;

            do
            {
                    Console.WriteLine("Tinta del boligrafo azul: {0}\nTinta del boligrafo rojo: {1}", boligrafoAzul.GetTinta(), boligrafoRojo.GetTinta());
                    Console.Write("Ingrese tinta a gastar del boligrafo azul: ");

                    tintaAGastar = byte.Parse(Console.ReadLine());
                    if (boligrafoAzul.Pintar(tintaAGastar, out dibujo))
                    {
                         Console.ForegroundColor = boligrafoAzul.GetColor();
                         Console.WriteLine(dibujo);
                         Console.ResetColor();
                    }
                    else
                    {
                         Console.WriteLine(dibujo);
                    }
                         Console.Write("Ingrese tinta a gastar del boligrafo rojo: ");
                         tintaAGastar = byte.Parse(Console.ReadLine());

                        if (boligrafoRojo.Pintar(tintaAGastar, out dibujo))    
                        {
                             Console.ForegroundColor = boligrafoRojo.GetColor();
                             Console.WriteLine(dibujo);
                             Console.ResetColor();
                        }
                        else
                        {
                             Console.WriteLine(dibujo);
                        }
            }while(tintaAGastar >= 0);

            
            Console.ReadKey();
        }
    }
}
