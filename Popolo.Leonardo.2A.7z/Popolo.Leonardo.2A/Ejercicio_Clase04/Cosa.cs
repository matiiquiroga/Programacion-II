﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_Clase04
{
    class Cosa
    {
        public string cadena;
        public double numero;
        public DateTime fecha;

        public static string Mostrar(Cosa cosita)
        {
            return cosita.Mostrar();
        }
        private string Mostrar()
        {
            string retorno = "";

            retorno = this.cadena + " " + this.numero.ToString() + " " + this.fecha.ToLongDateString();

            return retorno;
        }
        public void EstablecerValor(string cadena)
        {
            this.cadena = cadena;
        }
        public void EstablecerValor(string cadena, double numerito)
        {
            this.cadena = cadena;
            this.numero = numerito;
        }
        public void EstablecerValor(string cadena, double numerito, DateTime fechita)
        {
            this.cadena = cadena;
            this.numero = numerito;
            this.fecha = fechita;
        }
        public Cosa()
        {
            this.cadena = "sin valor";
            this.fecha = DateTime.Now;
            this.numero = 1.9;
        }
        public Cosa(string c)
        {
            this.cadena = c;
            this.fecha = DateTime.Now;
            this.numero = 1.9;
        }
    }
}
