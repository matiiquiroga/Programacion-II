﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clase07;

namespace ProyectoWinForm
{
    public partial class frmTempera : Form
    {
        private Tempera _miTempera;

        public Tempera MiTempera {
            get
            {
                return this._miTempera;
            }
        }

        public frmTempera()
        {
            InitializeComponent();

            foreach(ConsoleColor color in Enum.GetValues(typeof(ConsoleColor)))
            this.comboBox1.Items.Add(color);

            this.comboBox1.SelectedItem = ConsoleColor.Blue;
        }

        public frmTempera(Tempera tempera) : this()
        {
            this._miTempera = tempera;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            _miTempera = new Tempera(sbyte.Parse(this.textBox2.Text),(ConsoleColor)comboBox1.SelectedItem, this.textBox1.Text);
            this.DialogResult = DialogResult.OK;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

    }
}
