﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_clase06
{
    public partial class Form1 : Form
    {
        private Ejercicio_clase05.Pluma _pluma;
        private Ejercicio_clase05.Tinta _tinta;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void tintaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTinta formulario = new frmTinta();

            formulario.Show();
        }
    }
}
