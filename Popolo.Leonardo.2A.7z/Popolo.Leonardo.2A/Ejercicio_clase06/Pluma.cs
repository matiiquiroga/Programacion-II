﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_clase05
{
    class Pluma
    {
        #region atributos

        private string _marca;
        private int _cantidad;
        private Tinta _tinta;

        #endregion

        #region constructores

        public Pluma()
        {
            this._marca = "Sin marca";
            this._cantidad = 0;
            this._tinta = null;
        }

        public Pluma(string marca) : this()
        {
            this._marca = marca;
        }

        public Pluma(string marca, int cantidad) : this(marca)
        {
            this._cantidad = cantidad;
        }

        public Pluma(string marca, int cantidad, Tinta tinta) : this(marca, cantidad)
        {
            this._tinta = tinta;
        }

        #endregion

        #region metodos

        private string Mostrar()
        {
            return this._marca + " " + this._cantidad + " " + Tinta.Mostrar(this._tinta);
        }

        #endregion

        #region operadores

        public static implicit operator string(Pluma plum)
        {
            string retorno;

            if (plum != null)
                retorno = plum.Mostrar();
            else
                retorno = " -- ";
            return retorno;
        }

        public static bool operator ==(Pluma plu, Tinta tin)
        {
            if ((object)plu != null && (object)tin != null)
            {
                if (plu._tinta == tin)
                    return true;
                else
                    return false;
            }
            else
                return false;
        }

        public static bool operator !=(Pluma plu, Tinta tin)
        {
             return !(plu == tin);      
        }

        public static Pluma operator +(Pluma plu, Tinta tin)
        {
            if (plu == tin && (plu._cantidad + 10) <= 100)
            {
                plu._cantidad += 10;
            }
                           
            return plu;
        }

        public static Pluma operator -(Pluma plu, Tinta tin)
        {
             if (plu == tin && (plu._cantidad - 5) >= 0)
             {
                 plu._cantidad = plu._cantidad - 5;
             }

             return plu;
        }
        #endregion
    }
}
