﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_05
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            int acum;
            int acum2;

            Console.Write("Ingrese un numero: ");
            num = Convert.ToInt32(Console.ReadLine());

            for (int i = 1; i <= num; i++)
            {
                acum = 0;
                acum2 = 0;
                for (int j = 1; j <= (i-1); j++)
                {
                    acum = acum + j;
                }
                for (int k = (i + 1); acum2 < acum; k++)
                {
                    acum2 = acum2 + k;

                    if(acum == acum2)
                    {
                        Console.WriteLine(i);
                        break;
                    }
                }
            }

            Console.ReadKey();
        }
    }
}
