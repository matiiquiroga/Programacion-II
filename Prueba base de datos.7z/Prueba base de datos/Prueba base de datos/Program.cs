﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using System.Xml.Serialization;

namespace Prueba_base_de_datos
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Televisor> lista = new List<Televisor>();
            XmlSerializer serializador = new XmlSerializer(typeof(List<Televisor>)); // clase publica y con constructor publico por defecto
            XmlTextWriter escritor = new XmlTextWriter("Televisores.xml", Encoding.UTF8);
            XmlTextReader lectorxml = new XmlTextReader("Televisores.xml");

            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);

            SqlCommand comando = new SqlCommand();

            comando.CommandText = "select * from Televisores";
            comando.CommandType = System.Data.CommandType.Text;
            comando.Connection = conexion;

            conexion.Open();

            SqlDataReader lector = comando.ExecuteReader();

            while (lector.Read())
            {
                Console.WriteLine(lector[0] + " - " + lector[1] + " - " + lector[2] + " - " + lector[3] + " - " + lector[4]);
                lista.Add(new Televisor(lector.GetInt32(0), lector.GetDouble(2), lector.GetString(1), lector.GetInt32(3), lector.GetString(4)));
            }

            conexion.Close();

            serializador.Serialize(escritor, lista);

            escritor.Close();

            List<Televisor> lista2 = (List<Televisor>)serializador.Deserialize(lectorxml);

            lectorxml.Close();

            conexion.Open();

            lector = comando.ExecuteReader();

            DataTable televisores = new DataTable("Televisores");

            televisores.Load(lector);

            televisores.WriteXmlSchema("Televisores_esquema.xml");

            televisores.WriteXml("Televisores_dt.xml");

            conexion.Close();

            DataTable nuevoDT = new DataTable();

            nuevoDT.ReadXmlSchema("Televisores_esquema.xml");
            nuevoDT.ReadXml("Televisores_dt.xml");

            Televisor tele1 = new Televisor(1234, 15000, "Samsung", 42, "EEUU");

            tele1.Insertar();

            /*foreach (Televisor c in lista)
            {
                Console.WriteLine(c);
            }

            foreach (Televisor c in lista2)
            {
                Console.WriteLine(c);
            }*/

            Console.ReadKey();
        }
    }
}
