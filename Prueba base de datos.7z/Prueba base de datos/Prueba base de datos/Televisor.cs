﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using System.Xml.Serialization;

namespace Prueba_base_de_datos
{
    public class Televisor
    {
        public int id;
        public double precio;
        public string marca;
        public int pulgadas;
        public string pais;

        public Televisor(int id, double precio, string marca, int pulgadas, string pais)
        {
            this.id = id;
            this.precio = precio;
            this.pulgadas = pulgadas;
            this.pais = pais;
            this.marca = marca;
        }

        public Televisor()
        {
            

            
        }

        public bool Insertar()
        {
            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);

            SqlCommand comando = new SqlCommand();

            comando.CommandText = "insert into Televisores values (" + this.id + ", '" + this.marca + "' ," + this.precio + ", " + this.pulgadas + ", '" + this.pais + "')";
            comando.CommandType = System.Data.CommandType.Text;
            comando.Connection = conexion;

            try
            {
                conexion.Open();
                comando.ExecuteNonQuery();
                conexion.Close();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            } 
            
        }

        public override string ToString()
        {
            return this.id.ToString() + " " + this.marca + " " + this.precio.ToString() + " " + this.pulgadas.ToString() + " " + this.pais;
        }
    }
}
