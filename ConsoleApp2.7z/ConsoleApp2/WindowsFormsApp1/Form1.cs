using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
  public partial class Form1 : Form
  {
    private ConsoleApp1.pluma _pluma;
    private ConsoleApp1.tinta tinta;

    public Form1()
    {
      InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e)
    {

    }

    private void tintaToolStripMenuItem_Click(object sender, EventArgs e)
    {
      formTinta form = new formTinta();

      form.ShowDialog();
    }
  }
}
