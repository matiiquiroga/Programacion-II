using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
   class pluma
  {
    private string _marca;
    private int _cantidad;
    private tinta _tinta;

    public pluma()
    {
      this._cantidad = 0;
      this._marca = "sin marca";
      this._tinta = null;

    }

    public pluma(int cant) : this()
    {
      this._cantidad = cant;
    }

    public pluma(int cant, string marca) : this(cant)
    {
      this._marca = marca;
    }
    
    public pluma(int cant, string marca, tinta tinta) : this(cant,marca)
    {
      this._tinta = tinta;
    }

    private string mostrar()
    {
       return "Marca de pluma: " + this._marca + " \nCantidad: " + this._cantidad + " " + tinta.mostrar(this._tinta) ;
    }

    public static implicit operator string(pluma pluma)
    {
      return pluma.mostrar();
    }

    public static bool operator ==(pluma pluma, tinta tinta)
    {
      bool retorno = false;

      if(pluma._tinta == tinta)
      {
        retorno = true;
      }

      return retorno;
    }

    public static bool operator !=(pluma pluma, tinta tinta)
    {
      return !(pluma == tinta);
    }

    public static pluma operator +(pluma pluma, tinta tinta) // primero deberia chequear la cantidad de la tinta o 
    {                                                        //sobrecargarla y despues ffijarme que no supère los 100 OJO.
      if (pluma._tinta == tinta && pluma._cantidad<100)       
      {
        pluma._cantidad = pluma._cantidad + 10;
      }
      else if (pluma._tinta == tinta && pluma._cantidad >= 100)
      {
        pluma._cantidad = 100;
      }
      return pluma;
    }

    public static pluma operator -(pluma pluma, tinta tinta)
    {
      if (pluma._tinta == tinta && pluma._cantidad >= 0)
      {
        pluma._cantidad= pluma._cantidad-15;
      }
      else if(pluma._tinta == tinta && pluma._cantidad <= 0)
      {
        pluma._cantidad = 0;
      }

      return pluma;
    }

  }
}
