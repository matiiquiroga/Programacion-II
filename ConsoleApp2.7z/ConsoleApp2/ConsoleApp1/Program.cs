using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
    static void Main(string[] args)
    {
      Console.Beep();
      tinta miTintilla = new tinta(ConsoleColor.DarkMagenta,eTipoTinta.Comun);
      tinta miTinta = new tinta();
      bool todoOk;

      //  Console.WriteLine(tinta.mostrar(miTintilla));

      todoOk = miTintilla == miTinta;

      if (todoOk)
        Console.WriteLine("las tintas son iguales");
      else
        Console.WriteLine("las tintas son diferentes");
      Console.ReadKey();

      pluma mipluma = new pluma(50, "bic", miTinta);

      Console.WriteLine(mipluma);
      Console.ReadKey();

      todoOk = mipluma == miTinta;
      if (todoOk)
      {
        Console.WriteLine("la tinta de la pluma es igual a tuTinta!");
      }
      else
      {
        Console.WriteLine("la tinta de la pluma es DIFERENTE a tuTinta!");
      }
      Console.ReadKey();


      mipluma = mipluma + miTinta;
      Console.WriteLine("la pluma es ahora: \n");
      Console.WriteLine(mipluma);

      mipluma = mipluma - miTinta;
      Console.WriteLine("la pluma es ahora: \n");
      Console.WriteLine(mipluma);
      mipluma = mipluma - miTinta;
      Console.WriteLine("la pluma es ahora: \n");
      Console.WriteLine(mipluma);
      mipluma = mipluma - miTinta;
      Console.WriteLine("la pluma es ahora: \n");
      Console.WriteLine(mipluma);
      mipluma = mipluma - miTinta;
      Console.WriteLine("la pluma es ahora: \n");
      Console.WriteLine(mipluma);
      mipluma = mipluma - miTinta;
      Console.WriteLine("la pluma es ahora: \n");
      Console.WriteLine(mipluma); mipluma = mipluma - miTinta;
      Console.WriteLine("la pluma es ahora: \n");
      Console.WriteLine(mipluma);

      Console.ReadKey();










    }
        
    }
}
