﻿public enum eTipoTinta
{
    Comun,
    China,
    ConBrillita
}   